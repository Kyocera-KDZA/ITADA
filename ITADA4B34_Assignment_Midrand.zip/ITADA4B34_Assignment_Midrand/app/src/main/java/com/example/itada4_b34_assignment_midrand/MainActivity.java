package com.example.itada4_b34_assignment_midrand;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    sqllite_database databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        databaseHelper = new sqllite_database(MainActivity.this);
        Button insert = findViewById(R.id.register);
        Button update = findViewById(R.id.update);
        Button delete = findViewById(R.id.delete);



}