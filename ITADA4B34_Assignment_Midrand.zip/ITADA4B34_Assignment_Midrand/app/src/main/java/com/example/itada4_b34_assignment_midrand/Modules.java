package com.example.itada4_b34_assignment_midrand;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class Modules {

    //Registering User
    public void AddUser(UserModule user)
    { SQLiteDatabase db=this.getWritableDatabase(); ContentValues contentValues=new ContentValues();
        contentValues.put(username,user.getUsername());
        contentValues.put(email,user.getEmail());
        contentValues.put(type,user.getType());
        contentValues.put(password,user.getPassword());
        db.insert(AYIG,null,contentValues);
        db.close();
    }

    //Updating User
    public int updateUser(UserModule user)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(username,user.getUsername());
        contentValues.put(email,user.getEmail());
        contentValues.put(type,user.getType());
        contentValues.put(password,user.getPassword());
        db.insert(AYIG,null,contentValues);
        db.close();

        return db.update(AYIG, contentValues, ID + "=?", new String[]{String.valueOf(UserModule.getId())});
    }

    //Removing user
    public void deleteUser(String id)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete(AYIG,ID+"=?",new String[]{id});
        db.close();
    }

    //Returning a user
    public UserModule getUser(int id)
    {
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.query(AYIG,new String[]{ID,username,email,username,password},ID+" = ?",new String[]{String.valueOf(id)},null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        UserModule user =new UserModule(cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4));
        db.close();
        return user;
    }

}
